from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from . import util
import markdown

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def entry_page(request, title):
	if util.get_entry(title)== None:
		text= f"The page '{title}' Doesn't Exist!"
		return render(request, "encyclopedia/error.html", {
			"text": text
		})
	else:
		md = markdown.Markdown()
		page = md.convert(util.get_entry(title))
		return render(request, "encyclopedia/page.html",{
			"page": page,
			"title": title,
		})


def search(request):
	entries= util.list_entries()
	if request.method == 'GET':
		query=request.GET.get('q')
		if query == "":
			return render(request, "encyclopedia/index.html", {
        		"entries": entries
    		})
		if util.get_entry(query)!= None:
			return HttpResponseRedirect(f"/wiki/{query}")
		else:
			wordlist=[]
			subtext=query
			for word in entries:
				i=0
				for l in word:
					if l.lower()==subtext[i].lower():
						i=i+1
					else:
						i=0
					if i==len(subtext):
						wordlist.append(word)
						break
			check= False
			if len(wordlist) == 0:
				check = True
			return render(request, "encyclopedia/search.html", {
				"entries": wordlist,
				"query": query,
				"check": check,
				})

def random(request):
	import random
	entries=[]
	entries= util.list_entries()
	length= len(entries)
	i= random.randint(0, length-1)
	entry= entries[i]
	return HttpResponseRedirect(f"/wiki/{entry}")



def create(request):
	if request.method == 'POST':
		title= request.POST.get('title')
		content = request.POST.get('ContentPage')
		if title == "":
			text= f"Page cannot be created without the title"
			return render(request, "encyclopedia/error.html", {"text":text})
		elif util.get_entry(title) != None:
			text= f"the page '{title}' Already Exist!"
			return render(request, "encyclopedia/error.html", {"text":text})
		else:
			util.save_entry(title,content)
			return HttpResponseRedirect(f"/wiki/{title}")

	else:
		return render(request, "encyclopedia/create.html")


def edit(request):
	primary, title  = request.META.get('HTTP_REFERER').split('/')[-2:] #secondry is title here
	contentInitial = util.get_entry(title)

	if request.method == 'POST':
		content = request.POST.get('Content')		
		util.save_entry(title,content)
		md = markdown.Markdown()
		page = md.convert(content)
		return render(request, "encyclopedia/page.html",{
			"page": page,
			"title": title,
		})

	else:
		return render(request, "encyclopedia/edit.html",{
			"content": contentInitial
		})