#Programming 
programming is a tool in which we use algorithms to solve a particular problem.