## JAVA

Java is an object-oriented programming language.