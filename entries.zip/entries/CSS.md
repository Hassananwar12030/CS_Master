# CSS

CSS is a language that can be used to add style to an [HTML](/wiki/HTML) page.
